"""Reproduce the151-primary-publication D-by-V heatmap. Python+openpyxl; optional Inkscape exports. Data are author-confirmed; no generative image tool is used."""
from pathlib import Path
import csv
import subprocess
import xml.etree.ElementTree as E

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'Figures'
OUT.mkdir(parents=True,exist_ok=True)
SOURCE = ROOT / 'Figure4_primary_151.csv'
rows = list(csv.DictReader(SOURCE.open(encoding='utf-8-sig', newline='')))
assert all(r['Primary analysis']=='Yes' for r in rows)
assert len({r['Stable study ID'] for r in rows})==len(rows)
matrix = [[sum(r['D'] == f'D{i}' and r['V'] == f'V{j}' for r in rows) for j in range(4)] for i in range(5)]
assert matrix == [[0,3,1,0],[15,32,3,0],[21,11,16,1],[0,5,23,1],[0,1,18,0]]
assert len(rows) == 151 and sum(map(sum, matrix)) == 151

import json, hashlib
from openpyxl import load_workbook
ledger = ROOT.parent / 'Supplementary_Table_S1.xlsx'
wb=load_workbook(ledger,read_only=True,data_only=True)
it=wb['Evidence_matrix'].iter_rows(values_only=True)
headers=next(it)
evidence=[dict(zip(headers,r)) for r in it if r[0] is not None]
primary=[r for r in evidence if r['Primary analysis']=='Yes']
key=lambda r:(str(r['Stable study ID']).strip(),r['D'],r['V'])
assert len(evidence)==151 and len(primary)==151
assert sorted(map(key,rows))==sorted(map(key,primary)), 'CSV differs from adjudicated workbook'
assert [sum(r) for r in matrix]==[4,50,49,29,19]
assert [sum(r[j] for r in matrix) for j in range(4)]==[36,52,61,2]
assert matrix[4][3]==0
assert all(r['Primary analysis']=='Yes' for r in evidence)
report={'n_evidence':len(evidence),'n_primary':len(primary),'matrix_from_csv':matrix,'row_totals':[sum(r) for r in matrix],'column_totals':[sum(r[j] for r in matrix) for j in range(4)],'D4_V3':matrix[4][3],'csv_workbook_exact_match':True,'csv_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'workbook_sha256':hashlib.sha256(ledger.read_bytes()).hexdigest()}
(ROOT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

reference_mapping=json.loads((ROOT/'REFERENCE_MAPPING.json').read_text(encoding='utf-8'))
by_doi={r['doi'].lower().strip():r for r in reference_mapping if r.get('doi')}
assert all(str(by_doi[r['Stable study ID'].lower().strip()]['new_reference'])==r['Reference number'] for r in rows)

wb.close()

MAX=max(map(max,matrix))
with (OUT/'heatmap_counts.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['Decision level','V0','V1','V2','V3','total'])
    for i, row in enumerate(matrix): w.writerow([f'D{i}', *row, sum(row)])
    w.writerow(['total', *[sum(row[j] for row in matrix) for j in range(4)],len(rows)])
ns = 'http://www.w3.org/2000/svg'
E.register_namespace('',ns)
s = E.Element(f'{{{ns}}}svg', width='180mm', height='83.5mm', viewBox='0 135 1800 835')
def add(tag, **attrs): return E.SubElement(s,f'{{{ns}}}{tag}',{k.replace('_','-'):str(v) for k,v in attrs.items()})
def text(x,y,value,size=26,color='#19324D',anchor='start',weight='normal'):
    add('text',x=x,y=y,font_family='Arial',font_size=size,fill=color,text_anchor=anchor,font_weight=weight).text=str(value)
def color(value):
    t=value/MAX
    a=(247,250,252); b=(32,94,153)
    return '#'+''.join(f'{round(a[k]+t*(b[k]-a[k])):02x}' for k in range(3))
add('rect',y=135,width=1800,height=835,fill='white')
text(850,175,'validation evidence level',28,anchor='middle',weight='bold')
labels=['D0  monitoring','D1  prediction','D2  recommendation','D3  executed adjustment','D4  closed-loop control']
x0,y0,cw,ch=460,245,215,125
for j in range(4): text(x0+cw*(j+.5),225,f'V{j}',28,anchor='middle',weight='bold')
text(1390,225,'total',25,anchor='middle')
for i,row in enumerate(matrix):
    text(435,y0+ch*(i+.5)+9,labels[i],25,anchor='end')
    for j,v in enumerate(row):
        add('rect',x=x0+j*cw,y=y0+i*ch,width=cw,height=ch,fill=color(v),stroke='white',stroke_width=4)
        text(x0+cw*(j+.5),y0+ch*(i+.5)+13,v,37,color='white' if v>=14 else '#19324D',anchor='middle',weight='bold')
    text(1390,y0+ch*(i+.5)+11,sum(row),29,anchor='middle')
text(435,928,'total',25,anchor='end')
for j in range(4):text(x0+cw*(j+.5),928,sum(row[j] for row in matrix),29,anchor='middle')
text(1390,928,len(rows),29,anchor='middle',weight='bold')
for k in range(240):add('rect',x=1515,y=y0+k*ch*5/240,width=30,height=ch*5/240+1,fill=color(MAX*(1-k/239)))
for v in [0,8,16,24,MAX]:text(1560,y0+(MAX-v)/MAX*ch*5+8,v,22)
text(1505,212,'count',24)
svg=OUT/'Figure4.svg'
E.ElementTree(s).write(svg,encoding='utf-8',xml_declaration=True)
import shutil
ink=Path(shutil.which('inkscape') or shutil.which('inkscape.com') or '__inkscape_not_found__')
if ink.exists():
    for ext in ['png','pdf']:
        subprocess.run([str(ink),str(svg),'--export-width=3600',f'--export-filename={svg.with_suffix("."+ext)}'],check=True)
print(matrix)
