Reproduce Figure 4 from an extracted Supplementary directory by running:
python heatmap_generation/draw_heatmap.py

The script reads Figure4_primary_151.csv, verifies its stable study IDs and D/V assignments against Supplementary_Table_S1.xlsx, checks the DOI/reference mapping, and writes Figure4.svg, heatmap_counts.csv and a freshly computed validation.json. Inkscape is optional for PDF/PNG export. Keep Supplementary_Table_S1.xlsx one directory above the script.

The workbook, the two evidence CSV views and the plotting-input CSV contain the same 151 primary publications. Expected D totals: 4, 50, 49, 29, 19; V totals: 36, 52, 61, 2; D4/V3 = 0. The matrix and graphical design are unchanged. Bibliographic-number alignment and documentation changes are distinct from the frozen evidence coding.

The recorded reproduction environment is Python 3.12.14 (Python Software Foundation), openpyxl 3.1.5 and optional Inkscape 1.4.4 (Inkscape Project) for PDF/PNG export. OpenAI Codex using GPT-6.1 (OpenAI) assisted script updating and consistency checks. The underlying study identities and evidence coding are author-confirmed; AI did not generate or alter those assignments.
